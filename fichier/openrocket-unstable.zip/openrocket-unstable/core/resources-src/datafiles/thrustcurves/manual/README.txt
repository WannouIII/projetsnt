
This directory contains manually added / modified thrust curves.
All other thrust curves are from www.thrustcurve.org
(all RASP and RSE files).

WECO_*.eng - Thrust curves for Weco Feuerwerk motors, created by Sampo N.

Klima_*.eng - Thrust curves for Klima motors, created by Leo Nutz

