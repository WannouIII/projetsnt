package net.sf.openrocket.document.events;

import java.util.EventObject;

public class DocumentChangeEvent extends EventObject {

	public DocumentChangeEvent(Object source) {
		super(source);
	}

}
