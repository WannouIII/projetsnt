package net.sf.openrocket.document.events;

public interface DocumentChangeListener {

	public void documentChanged(DocumentChangeEvent event);
	
}
