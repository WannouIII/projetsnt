package net.sf.openrocket.document;

import java.util.EventListener;

public interface UndoRedoListener extends EventListener {

	public void setAllValues();
}
