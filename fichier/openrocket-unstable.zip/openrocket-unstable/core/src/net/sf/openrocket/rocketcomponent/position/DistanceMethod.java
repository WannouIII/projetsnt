package net.sf.openrocket.rocketcomponent.position;


public interface DistanceMethod {
	public boolean clampToZero();
}