package net.sf.openrocket.document.events;


public class SimulationChangeEvent extends DocumentChangeEvent {

	public SimulationChangeEvent(Object source) {
		super(source);
	}

}
